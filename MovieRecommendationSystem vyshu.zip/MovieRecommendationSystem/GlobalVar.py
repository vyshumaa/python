import tkinter as tk
#
userid = 1
BigWindow = tk.Tk()


#data的位置
pathmovie = "/Users/stacy/code/MovieRecommendationSystem/data/movies.csv"
pathlink = "/Users/stacy/code/MovieRecommendationSystem/data/links.csv"
pathrating = "/Users/stacy/code/MovieRecommendationSystem/data/ratings.csv"
pathcosSim_svd = "/Users/stacy/code/MovieRecommendationSystem/data/cosSim.csv"#pickle
pathmovie_similar_svd = "/Users/stacy/code/MovieRecommendationSystem/data/movie_similar_svd.csv"
pathoffline_recommend_svd = "/Users/stacy/code/MovieRecommendationSystem/data/offline_recommend_svd.csv"
pathoffline_recommend_als = "/Users/stacy/code/MovieRecommendationSystem/data/offline_recommend_als.csv"
pathmovie_similar_svd ="/Users/stacy/code/MovieRecommendationSystem/data/movie_similar_svd.csv"
pathmovie_similar_als = "/Users/stacy/code/MovieRecommendationSystem/data/movie_similar_als.csv"
pathusers = "/Users/stacy/code/MovieRecommendationSystem/data/users.csv"

pathonline_recommend = "/Users/stacy/code/MovieRecommendationSystem/data/online_recommend.csv"

pathmovieidlist = "/Users/stacy/code/MovieRecommendationSystem/data/movieidlist.pickle"